create database employeemanagement;
use employeemanagement;

create table employee(name varchar(40), fname varchar(40), dob varchar(40), salary varchar(40), address varchar(40), phone varchar(40), email varchar(40), education varchar(40), designation varchar(40), addhar varchar(40), empId varchar(40));


create table login(username varchar(45), password varchar(45));
insert into login values("user", "password");
